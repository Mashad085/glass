const fs = require('fs').promises;
const path = require('path');
const bcrypt = require('bcryptjs');

class UserManager {
    constructor() {
        this.usersFile = path.join(__dirname, '../config/users.json');
    }

    /**
     * Load users from JSON file
     */
    async loadUsers() {
        try {
            const data = await fs.readFile(this.usersFile, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            console.error('Error loading users:', error.message);
            throw new Error('Failed to load users');
        }
    }

    /**
     * Save users to JSON file
     */
    async saveUsers(users) {
        try {
            await fs.writeFile(
                this.usersFile, 
                JSON.stringify(users, null, 2), 
                'utf8'
            );
        } catch (error) {
            console.error('Error saving users:', error.message);
            throw new Error('Failed to save users');
        }
    }

    /**
     * Authenticate user
     */
    async authenticate(username, password) {
        try {
            const users = await this.loadUsers();
            
            // Find user by username
            const user = users.find(u => u.username === username);
            
            if (!user) {
                return {
                    success: false,
                    message: 'User not found'
                };
            }

            // Check if user is active
            if (!user.active) {
                return {
                    success: false,
                    message: 'User account is inactive'
                };
            }

            // Verify password
            const isPasswordValid = await bcrypt.compare(password, user.password);
            
            if (!isPasswordValid) {
                return {
                    success: false,
                    message: 'Invalid password'
                };
            }

            // Update last login
            user.last_login = new Date().toISOString();
            await this.saveUsers(users);

            // Return user data without password
            const { password: _, ...userWithoutPassword } = user;
            
            return {
                success: true,
                message: 'Authentication successful',
                user: userWithoutPassword
            };
        } catch (error) {
            console.error('Authentication error:', error.message);
            return {
                success: false,
                message: 'Authentication failed: ' + error.message
            };
        }
    }


    /**
     * Get user by username
     */
    async getUserByUsername(username) {
        try {
            const users = await this.loadUsers();
            const user = users.find(u => u.username === username);
            
            if (!user) {
                return null;
            }

            // Return user without password
            const { password: _, ...userWithoutPassword } = user;
            return userWithoutPassword;
        } catch (error) {
            console.error('Error getting user:', error.message);
            return null;
        }
    }

    /**
     * Get user by ID
     */
    async getUserById(id) {
        try {
            const users = await this.loadUsers();
            const user = users.find(u => u.id === id);
            
            if (!user) {
                return null;
            }

            // Return user without password
            const { password: _, ...userWithoutPassword } = user;
            return userWithoutPassword;
        } catch (error) {
            console.error('Error getting user:', error.message);
            return null;
        }
    }

    /**
     * Create new user
     */
    async createUser(userData) {
        try {
            const users = await this.loadUsers();
            
            // Check if username already exists
            if (users.some(u => u.username === userData.username)) {
                return {
                    success: false,
                    message: 'Username already exists'
                };
            }

            // Hash password
            const hashedPassword = await bcrypt.hash(userData.password, 10);

            // Create new user object
            const newUser = {
                id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
                username: userData.username,
                password: hashedPassword,
                role: userData.role || 'operator',
                name: userData.name,
                email: userData.email,
                created_at: new Date().toISOString(),
                last_login: null,
                active: true
            };

            users.push(newUser);
            await this.saveUsers(users);

            const { password: _, ...userWithoutPassword } = newUser;
            
            return {
                success: true,
                message: 'User created successfully',
                user: userWithoutPassword
            };
        } catch (error) {
            console.error('Error creating user:', error.message);
            return {
                success: false,
                message: 'Failed to create user: ' + error.message
            };
        }
    }

    /**
     * Update user
     */
    async updateUser(id, updateData) {
        try {
            const users = await this.loadUsers();
            const userIndex = users.findIndex(u => u.id === id);
            
            if (userIndex === -1) {
                return {
                    success: false,
                    message: 'User not found'
                };
            }

            // If password is being updated, hash it
            if (updateData.password) {
                updateData.password = await bcrypt.hash(updateData.password, 10);
            }

            // Update user data
            users[userIndex] = {
                ...users[userIndex],
                ...updateData,
                id: users[userIndex].id, // Prevent ID change
                created_at: users[userIndex].created_at // Prevent created_at change
            };

            await this.saveUsers(users);

            const { password: _, ...userWithoutPassword } = users[userIndex];
            
            return {
                success: true,
                message: 'User updated successfully',
                user: userWithoutPassword
            };
        } catch (error) {
            console.error('Error updating user:', error.message);
            return {
                success: false,
                message: 'Failed to update user: ' + error.message
            };
        }
    }

    /**
     * Delete user (soft delete - set active to false)
     */
    async deleteUser(id) {
        try {
            const users = await this.loadUsers();
            const userIndex = users.findIndex(u => u.id === id);
            
            if (userIndex === -1) {
                return {
                    success: false,
                    message: 'User not found'
                };
            }

            // Soft delete
            users[userIndex].active = false;
            await this.saveUsers(users);

            return {
                success: true,
                message: 'User deleted successfully'
            };
        } catch (error) {
            console.error('Error deleting user:', error.message);
            return {
                success: false,
                message: 'Failed to delete user: ' + error.message
            };
        }
    }

    /**
     * Get all users
     */
    async getAllUsers() {
        try {
            const users = await this.loadUsers();
            
            // Return users without passwords
            return users.map(({ password: _, ...user }) => user);
        } catch (error) {
            console.error('Error getting users:', error.message);
            return [];
        }
    }

    /**
     * Generate password hash (utility function)
     */
    async generatePasswordHash(password) {
        return await bcrypt.hash(password, 10);
    }
}

module.exports = new UserManager();
