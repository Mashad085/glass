/**
 * Stats Router - VERIFIED EXPORT VERSION
 * File ini dijamin export dengan benar untuk Express
 */

var express = require('express');
var router = express.Router();

/**
 * Lookup vendor dari MAC address menggunakan oui_data global
 */
function lookupVendor(mac) {
    // Validasi input
    if (!mac) {
        return "Unknown";
    }
    
    // Validasi oui_data tersedia
    if (typeof oui_data === 'undefined' || !oui_data) {
        console.error('WARNING: oui_data is not available');
        return "Unknown";
    }
    
    // Normalisasi MAC address - hapus semua pemisah
    var normalized = mac.replace(/[:\-\s\.]/g, '').toUpperCase();
    
    if (normalized.length < 6) {
        return "Unknown";
    }
    
    // Ambil OUI (6 karakter pertama)
    var oui = normalized.substring(0, 6);
    
    // Coba berbagai format key yang mungkin ada di oui_data
    var formats = [
        oui,  // Format: AABBCC
        oui.substring(0, 2) + ":" + oui.substring(2, 4) + ":" + oui.substring(4, 6),  // Format: AA:BB:CC
        oui.substring(0, 2) + "-" + oui.substring(2, 4) + "-" + oui.substring(4, 6),  // Format: AA-BB-CC
        oui.toLowerCase(),  // Format: aabbcc
        oui.substring(0, 2) + ":" + oui.substring(2, 4) + ":" + oui.substring(4, 6).toLowerCase(),  // Format: AA:BB:cc
    ];
    
    // Cari vendor di oui_data
    for (var i = 0; i < formats.length; i++) {
        var key = formats[i];
        
        if (oui_data[key]) {
            var value = oui_data[key];
            
            // Jika value adalah string langsung
            if (typeof value === 'string') {
                return value;
            }
            
            // Jika value adalah object, cari property vendor
            if (typeof value === 'object') {
                if (value.vendor) return value.vendor;
                if (value['Vendor Name']) return value['Vendor Name'];
                if (value.name) return value.name;
                if (value.vendorName) return value.vendorName;
            }
        }
    }
    
    return "Unknown";
}

/**
 * GET / - Statistik vendor
 */
router.get('/', function (req, res, next) {
    var stat_data = {};
    
    // Validasi dhcp_lease_data
    if (typeof dhcp_lease_data === 'undefined' || !dhcp_lease_data) {
        return res.status(500).json({
            error: 'dhcp_lease_data is not available'
        });
    }
    
    // Proses setiap lease
    for (var key in dhcp_lease_data) {
        var lease = dhcp_lease_data[key];
        var vendor = "Unknown";
        
        // Lookup vendor dari MAC
        if (lease.mac) {
            vendor = lookupVendor(lease.mac);
        }
        
        // Update vendor di lease data
        lease.mac_oui_vendor = vendor;
        
        // Hitung statistik
        if (!stat_data[vendor]) {
            stat_data[vendor] = 0;
        }
        stat_data[vendor]++;
    }
    
    // Kirim response
    res.setHeader('Content-Type', 'application/json');
    res.send(JSON.stringify(stat_data));
});

// PENTING: Export router (bukan object lain!)
module.exports = router;
