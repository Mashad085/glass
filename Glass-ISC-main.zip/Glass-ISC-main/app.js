var express      = require('express');
var path         = require('path');
var logger       = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser   = require('body-parser');
const execSync   = require('child_process').execSync;
var app          = express();
var json_file    = require('jsonfile');
var glass_config = json_file.readFileSync('config/glass_config.json');
var session      = require('express-session');
var bcrypt       = require('bcryptjs');

// ==================== WEBSOCKET SETUP ====================
const WebSocket = require('ws');
const ws_port   = glass_config.ws_port || 8080;

console.log("[Glass Server] Websocket server starting on port: " + ws_port);

// Deklarasikan wss di global scope
global.wss = new WebSocket.Server({port: ws_port});

// ==================== USER MANAGER ====================
const UserManager = require('./core/user-manager');

// ==================== AUTHENTICATION MIDDLEWARE ====================

// Session configuration
app.use(session({
    secret: process.env.SESSION_SECRET || 'dhcp-monitoring-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 jam
    }
}));

// Middleware untuk cek login
const requireLogin = (req, res, next) => {
    if (req.session.user) {
        next(); // User sudah login
    } else {
        // Jika request API, return JSON error
        if (req.path.startsWith('/api/')) {
            return res.status(401).json({
                error: 'Unauthorized',
                message: 'Please login first'
            });
        }
        // Jika request web page, redirect ke login
        res.redirect('/login');
    }
};

// Middleware untuk role-based access
const requireRole = (roles) => {
    return (req, res, next) => {
        if (!req.session.user) {
            if (req.path.startsWith('/api/')) {
                return res.status(401).json({
                    error: 'Unauthorized',
                    message: 'Please login first'
                });
            }
            return res.redirect('/login');
        }
        
        if (!roles.includes(req.session.user.role)) {
            if (req.path.startsWith('/api/')) {
                return res.status(403).json({
                    error: 'Forbidden',
                    message: 'Insufficient permissions'
                });
            }
            return res.status(403).send(`
                <html>
                    <head>
                        <title>Access Denied</title>
                        <style>
                            body { font-family: Arial; padding: 50px; text-align: center; }
                            .error { color: red; margin: 20px; }
                        </style>
                    </head>
                    <body>
                        <h2>Access Denied</h2>
                        <p class="error">You don't have permission to access this page.</p>
                        <p><a href="/">Return to Dashboard</a></p>
                    </body>
                </html>
            `);
        }
        
        next();
    };
};

// Middleware untuk inject user data ke template
app.use((req, res, next) => {
    if (req.session.user) {
        res.locals.user = req.session.user;
        res.locals.isAdmin = req.session.user.role === 'admin';
        res.locals.isOperator = req.session.user.role === 'operator';
    }
    next();
});

/**
 * Init Express plugins
 */
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

/**
 * IP Filter
 */
if (glass_config.ip_ranges_to_allow[0] !== "") {
	var ip_filter = require('express-ipfilter').IpFilter;
	var ips       = glass_config.ip_ranges_to_allow;
	app.use(ip_filter(ips, {mode: 'allow'}));
}

// ==================== PUBLIC ROUTES (Tidak perlu login) ====================

// Login page
app.get('/login', (req, res) => {
    if (req.session.user) {
        return res.redirect('/');
    }
    res.sendFile(path.join(__dirname, 'public/login.html'));
});

// Logout
app.get('/logout', (req, res) => {
    console.log(`[AUTH] User ${req.session.user?.username} logged out`);
    req.session.destroy();
    res.redirect('/login?message=logged_out');
});

// Login handler
app.post('/login', express.urlencoded({ extended: true }), async (req, res) => {
    const { username, password } = req.body;
    
    console.log(`[AUTH] Login attempt from ${req.ip}: ${username}`);
    
    try {
        const authResult = await UserManager.authenticate(username, password);
        
        if (authResult.success) {
            // Simpan user ke session (sudah tanpa password dari UserManager)
            req.session.user = authResult.user;
            
            console.log(`[AUTH] ✅ User ${username} (${authResult.user.role}) logged in`);
            
            res.redirect('/');
        } else {
            console.warn(`[AUTH] ❌ Failed login for ${username}: ${authResult.message}`);
            res.redirect('/login?error=auth_failed');
        }
    } catch (error) {
        console.error('[AUTH] Login error:', error);
        res.redirect('/login?error=server_error');
    }
});

// Health check endpoint (public)
app.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        service: 'DHCP Monitor'
    });
});

// ==================== WEB ROUTES DENGAN ROLE PERMISSIONS ====================

// Dashboard (semua user bisa akses)
app.use('/', requireLogin, requireRole(['admin', 'operator']), require('./routes/index'));

// User Management (admin only)
app.use('/users', requireLogin, requireRole(['admin']), require('./routes/users'));

// Statistics (semua user bisa akses)
app.use('/get_stats', requireLogin, requireRole(['admin', 'operator']), require('./routes/get_stats'));
app.use('/dhcp_statistics', requireLogin, requireRole(['admin', 'operator']), require('./routes/dhcp_statistics_page'));

// DHCP Leases Management (semua user bisa akses)
app.use('/dhcp_leases', requireLogin, requireRole(['admin', 'operator']), require('./routes/dhcp_leases'));
app.use('/dhcp_lease_search', requireLogin, requireRole(['admin', 'operator']), require('./routes/dhcp_lease_search'));

// DHCP Log (admin only)
app.use('/dhcp_log', requireLogin, requireRole(['admin']), require('./routes/dhcp_log'));

// DHCP Configuration (admin only)
app.use('/dhcp_config', requireLogin, requireRole(['admin']), require('./routes/dhcp_config'));
app.use('/dhcp_config_snapshots', requireLogin, requireRole(['admin']), require('./routes/dhcp_config_snapshots'));
app.use('/dhcp_config_snapshot_view', requireLogin, requireRole(['admin']), require('./routes/dhcp_config_snapshot_view'));
app.use('/dhcp_config_save', requireLogin, requireRole(['admin']), require('./routes/dhcp_config_save'));
app.use('/dhcp_start_stop_restart', requireLogin, requireRole(['admin']), require('./routes/dhcp_start_stop_restart'));

// API Examples (semua user bisa akses)
app.use('/api_examples', requireLogin, requireRole(['admin', 'operator']), require('./routes/api_examples'));

// Glass Settings (admin only)
app.use('/glass_settings', requireLogin, requireRole(['admin']), require('./routes/glass_settings'));
app.use('/glass_settings_save', requireLogin, requireRole(['admin']), require('./routes/glass_settings_save'));

// Glass Alerts (admin only)
app.use('/glass_alerts', requireLogin, requireRole(['admin']), require('./routes/glass_alerts'));
app.use('/glass_alert_settings_save', requireLogin, requireRole(['admin']), require('./routes/glass_alert_settings_save'));

// ==================== API ROUTES DENGAN ROLE PERMISSIONS ====================

// Public info APIs (semua user bisa akses)
app.use('/api/get_active_leases/', requireLogin, requireRole(['admin', 'operator']), require('./api/get_active_leases'));
app.use('/api/get_subnet_details/', requireLogin, requireRole(['admin', 'operator']), require('./api/get_subnet_details'));
app.use('/api/get_vendor_count/', requireLogin, requireRole(['admin', 'operator']), require('./api/get_vendor_count'));
app.use('/api/get_mac_oui_count_by_vendor/', requireLogin, requireRole(['admin', 'operator']), require('./api/get_mac_oui_count_by_vendor'));
app.use('/api/get_dhcp_requests/', requireLogin, requireRole(['admin', 'operator']), require('./api/get_dhcp_requests'));
app.use('/api/get_server_info/', requireLogin, requireRole(['admin', 'operator']), require('./api/get_server_info'));
app.use('/api/get_mac_oui_list/', requireLogin, requireRole(['admin', 'operator']), require('./api/get_mac_oui_list'));
app.use('/api/get_websocket_config/', requireLogin, requireRole(['admin', 'operator']), require('./api/get_websocket_config'));

// Configuration APIs (admin only)
app.use('/api/get_glass_config/', requireLogin, requireRole(['admin']), require('./api/get_glass_config'));

// ==================== USER MANAGEMENT API ROUTES ====================
// Update user (admin only)
app.put('/api/users/:id', requireLogin, requireRole(['admin']), express.json(), async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        const updateData = req.body;
        
        const result = await UserManager.updateUser(userId, updateData);
        
        if (result.success) {
            res.json(result);
        } else {
            res.status(400).json(result);
        }
    } catch (error) {
        console.error('[API] Update user error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update user'
        });
    }
});

// Delete user (admin only)
app.delete('/api/users/:id', requireLogin, requireRole(['admin']), async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        
        // Prevent deleting yourself
        if (userId === req.session.user.id) {
            return res.status(400).json({
                success: false,
                error: 'You cannot delete your own account'
            });
        }
        
        const result = await UserManager.deleteUser(userId);
        
        if (result.success) {
            res.json(result);
        } else {
            res.status(400).json(result);
        }
    } catch (error) {
        console.error('[API] Delete user error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete user'
        });
    }
});
// User profile API (current user)
app.get('/api/profile', requireLogin, async (req, res) => {
    try {
        const user = await UserManager.getUserById(req.session.user.id);
        if (user) {
            res.json({
                success: true,
                user: user
            });
        } else {
            res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }
    } catch (error) {
        console.error('[API] Get profile error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get profile'
        });
    }
});

// Get all users (admin only)
app.get('/api/users', requireLogin, requireRole(['admin']), async (req, res) => {
    try {
        const users = await UserManager.getAllUsers();
        res.json({
            success: true,
            count: users.length,
            users: users
        });
    } catch (error) {
        console.error('[API] Get users error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get users'
        });
    }
});

// Create new user (admin only)
app.post('/api/users', requireLogin, requireRole(['admin']), express.json(), async (req, res) => {
    try {
        const { username, password, role, name, email } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({
                success: false,
                error: 'Username and password are required'
            });
        }
        
        const result = await UserManager.createUser({
            username,
            password,
            role: role || 'operator',
            name,
            email
        });
        
        if (result.success) {
            res.json(result);
        } else {
            res.status(400).json(result);
        }
    } catch (error) {
        console.error('[API] Create user error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to create user'
        });
    }
});

// Change password (current user)
app.post('/api/change-password', requireLogin, express.json(), async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;
        
        if (!currentPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                error: 'Both current and new password are required'
            });
        }
        
        const users = await UserManager.loadUsers();
        const user = users.find(u => u.id === req.session.user.id);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }
        
        const passwordMatch = await bcrypt.compare(currentPassword, user.password);
        if (!passwordMatch) {
            return res.status(400).json({
                success: false,
                error: 'Current password is incorrect'
            });
        }
        
        const result = await UserManager.updateUser(req.session.user.id, {
            password: newPassword
        });
        
        if (result.success) {
            req.session.destroy();
            res.json({
                success: true,
                message: 'Password changed successfully. Please login again.'
            });
        } else {
            res.status(400).json(result);
        }
    } catch (error) {
        console.error('[API] Change password error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to change password'
        });
    }
});

// Profile page (current user)
app.get('/profile', requireLogin, async (req, res) => {
    try {
        const user = await UserManager.getUserById(req.session.user.id);
        
        if (!user) {
            return res.redirect('/logout');
        }
        
        res.send(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>My Profile - DHCP Monitor</title>
                <style>
                    body { font-family: Arial; padding: 20px; background: #f0f0f0; }
                    .container { max-width: 800px; margin: 0 auto; }
                    .profile-card { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
                    .info-row { margin: 15px 0; display: flex; border-bottom: 1px solid #eee; padding: 10px 0; }
                    .info-label { font-weight: bold; width: 150px; color: #555; }
                    .info-value { flex: 1; color: #333; }
                    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
                    .links { margin-top: 30px; padding-top: 20px; border-top: 2px solid #eee; }
                    .links a { margin-right: 15px; color: #007bff; text-decoration: none; }
                    .links a:hover { text-decoration: underline; }
                    .badge { display: inline-block; padding: 5px 10px; border-radius: 5px; font-size: 12px; }
                    .badge-admin { background: #dc3545; color: white; }
                    .badge-operator { background: #28a745; color: white; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>My Profile</h1>
                        <span class="badge ${user.role === 'admin' ? 'badge-admin' : 'badge-operator'}">${user.role.toUpperCase()}</span>
                    </div>
                    <div class="profile-card">
                        <div class="info-row">
                            <div class="info-label">Username:</div>
                            <div class="info-value">${user.username}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Name:</div>
                            <div class="info-value">${user.name || '-'}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Email:</div>
                            <div class="info-value">${user.email || '-'}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Role:</div>
                            <div class="info-value">${user.role}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Account Status:</div>
                            <div class="info-value">${user.active ? '✅ Active' : '❌ Inactive'}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Last Login:</div>
                            <div class="info-value">${user.last_login ? new Date(user.last_login).toLocaleString() : 'Never'}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Account Created:</div>
                            <div class="info-value">${new Date(user.created_at).toLocaleString()}</div>
                        </div>
                    </div>
                    <div class="links">
                        <a href="/">← Back to Dashboard</a>
                        <a href="/logout">Logout</a>
                    </div>
                </div>
            </body>
            </html>
        `);
    } catch (error) {
        console.error('[Profile] Error:', error);
        res.redirect('/logout');
    }
});

// ==================== ERROR HANDLING ====================

app.set('view engine', 'html');

/**
 * Catch 404
 */
app.use(function (req, res, next) {
	var err    = new Error('Not Found');
	err.status = 404;
	next(err);
});

/**
 * Error handler
 */
app.use(function (err, req, res, next) {
	res.locals.message = err.message;
	res.locals.error   = req.app.get('env') === 'development' ? err : {};

	res.status(err.status || 500);
	res.send(err.message);
});

module.exports              = app;
module.exports.glass_config = glass_config;

/**
 * App Globals
 */
global.cpu_utilization                = 0;
global.current_leases_per_second      = 0;
global.current_time                   = 0;
global.debug_watch_lease_parse_stream = 0;
global.dhcp_lease_data                = {};
global.dhcp_requests                  = {};
global.leases_last_update_time        = 0;
global.leases_per_minute              = 0;
global.leases_per_minute_counter      = 0;
global.leases_per_minute_data         = [];
global.leases_per_second              = 0;
global.listening_to_log_file          = 0;
global.oui_data                       = {};
global.total_leases                   = 0;
global.socket_clients                 = 0;

/**
 * Server hostname
 */
try {
    global.host_name = execSync("cat /etc/hostname").toString().replace("\n", "");
} catch (e) {
    global.host_name = execSync("/usr/bin/env hostname -s").toString().replace("\n", "");
}

/**
 * Pull in core handlers
 */
let oui_reader           = require('./core/oui-reader');
let dhcp_leases          = require('./core/dhcp-leases');
let glass_config_watcher = require('./core/glass-config-watcher');
let dhcp_log_watcher     = require('./core/dhcp-log-watcher');
let app_timers           = require('./core/app-timers');

/**
 * Run routines
 */
oui_reader.initOuiDatabase();
dhcp_leases.parseLeasesFileOnce(glass_config);
dhcp_leases.startLeaseListener(glass_config);
dhcp_leases.setLeasesCleanTimer();
glass_config_watcher.init();
dhcp_log_watcher.init(glass_config);

/**
 * Timers
 */
app_timers.clearStaleWebsocketConnectionsTimer();
app_timers.pollCpuUtilizationTimer();
app_timers.purgeRequestDataCompleteTimer();
app_timers.purgeRequestDataTimer();
app_timers.startDashboardTimer();
app_timers.startLeasesPerMinuteCalculator();

// ==================== WEBSOCKET EVENT HANDLERS ====================

wss.on('connection', function connection(ws) {
	socket_clients++;
	console.log("[WS] CLIENT_CONNECT: Socket clients (" + socket_clients + ")");

	if (!listening_to_log_file) {
		listening_to_log_file = 1;
	}

});

wss.on('close', function close() {
	socket_clients--;
	console.log("[WS] CLIENT_DISCONNECT: Socket clients (" + socket_clients + ")");
});

wss.on('connection', function connection(ws) {
	ws.isAlive = true;
	ws.on('pong', heartbeat);
	ws.event_subscription = [];

	ws.on('message', function incoming(data) {
		if (data !== "" && isJson(data)) {
			var json = JSON.parse(data);
			if (typeof json["event_subscription"] !== "undefined") {
				console.log("[WS] Incoming Subscription '%s'", json['event_subscription']);
				ws.event_subscription[json["event_subscription"]] = 1;
			}
			if (typeof json["event_unsubscribe"] !== "undefined") {
				console.log("[WS] event_unsubscribe '%s'", json['event_unsubscribe']);
				delete ws.event_subscription[json["event_unsubscribe"]];
			}
			if (typeof json["all_events"] !== "undefined") {
				console.log("[WS] event_unsubscribe '%s'", json['event_unsubscribe']);
				ws.event_subscription = [];
			}
		}
	});

	stale_connections_audit();
});

get_socket_clients_connected_count = function () {
	wss.clients.forEach(function each(client) {
		if (client.readyState === WebSocket.OPEN) {
			socket_clients++;
		}
	});
	return socket_clients;
};

wss.broadcast = function broadcast(data) {
	wss.clients.forEach(function each(client) {
		if (client.readyState === WebSocket.OPEN) {
			client.send(data);
		}
	});
};

wss.broadcast_event = function broadcast(data, event) {
	wss.clients.forEach(function each(client) {
		if (client.readyState === WebSocket.OPEN) {
			if (client.event_subscription[event])
				client.send(JSON.stringify({"event": event, "data": data}));
		}
	});
};

stale_connections_audit = function() {
	socket_clients = 0;
	wss.clients.forEach(function each(ws) {
		if (ws.isAlive === false) return ws.terminate();

		ws.isAlive = false;
		ws.ping('', false, true);

		socket_clients++;
	});

	console.log("[WS] STATUS: Socket clients (" + socket_clients + ")");
};

heartbeat = function() {
	this.isAlive = true;
};

isJson = function(str) {
	try {
		JSON.parse(str);
	} catch (e) {
		return false;
	}
	return true;
};

are_clients_subscribed_to_ws_event = function(event) {
	if (typeof wss === "undefined")
		return false;

	var is_listening = false;

	wss.clients.forEach(function each(ws) {

		/**
		 * Count event listeners
		 */
		for (var event_listening in ws.event_subscription) {
			if (event_listening === event) {
				is_listening = true;
				return true;
			}
		}
	});

	return is_listening;
};

/**
 * Alert Checks
 */

alert_status = [];
alert_status['leases_per_minute'] = 0;
setTimeout(function () {
	console.log("[Glass Server] Alert loop started");

	let alert_check_timer = setInterval(function () {
		// console.log("[Timer] Alert Timer check");
		if (glass_config.leases_per_minute_threshold > 0) {
			// console.log("[Timer] lpm: %s lpm_th: %s", leases_per_minute, glass_config.leases_per_minute_threshold);
			if (leases_per_minute <= glass_config.leases_per_minute_threshold && alert_status['leases_per_minute'] === 0) {
				alert_status['leases_per_minute'] = 1;

				slack_message(":warning: CRITICAL: DHCP leases per minute have dropped below threshold " +
								  "(" + parseInt(glass_config.leases_per_minute_threshold).toLocaleString('en') + ") " +
								  "Current (" + parseInt(leases_per_minute).toLocaleString('en') + ")");

				email_alert("CRITICAL: Leases Per Minute Threshold", "DHCP leases per minute dropped below critical threshold <br><br>" +
					"Threshold: (" + parseInt(glass_config.leases_per_minute_threshold).toLocaleString('en') + ") <br>" +
					"Current: (" + parseInt(leases_per_minute).toLocaleString('en') + ") <br><br>" +
					"This is usually indicative of a process or hardware problem and needs to be addressed immediately");
			}
			else if (leases_per_minute >= glass_config.leases_per_minute_threshold && alert_status['leases_per_minute'] === 1) {
				alert_status['leases_per_minute'] = 0;

				slack_message(":white_check_mark: CLEAR: DHCP leases per minute have returned to above threshold " +
								  "(" + parseInt(glass_config.leases_per_minute_threshold).toLocaleString('en') + ") " +
								  "Current (" + parseInt(leases_per_minute).toLocaleString('en') + ")");

				email_alert("CLEAR: Leases Per Minute Threshold", "DHCP leases per minute have returned to normal <br><br>" +
					"Threshold: (" + parseInt(glass_config.leases_per_minute_threshold).toLocaleString('en') + ") <br>" +
					"Current: (" + parseInt(leases_per_minute).toLocaleString('en') + ")"
				);

			}
		}
	}, (5 * 1000));

	alert_status_networks_warning  = [];
	alert_status_networks_critical = [];

	let alert_subnet_check_timer = setInterval(function () {
		// console.log("[Timer] Alert Timer check - subnets");

		if (glass_config.shared_network_warning_threshold > 0 || glass_config.shared_network_critical_threshold > 0) {
			const execSync = require('child_process').execSync;
			output         = execSync('./bin/dhcpd-pools -c ' + glass_config.config_file + ' -l ' + glass_config.leases_file + ' -f j -A -s e');
			var dhcp_data  = JSON.parse(output);

			/*
			 * Iterate through Shared Networks
			 */
			for (var i = 0; i < dhcp_data['shared-networks'].length; i++) {
				utilization = round(parseFloat(dhcp_data['shared-networks'][i].used / dhcp_data['shared-networks'][i].defined) * 100, 2);

				if (isNaN(utilization))
					utilization = 0;


				/* Initialize these array buckets */
				if (typeof alert_status_networks_warning[dhcp_data['shared-networks'][i].location] === "undefined")
					alert_status_networks_warning[dhcp_data['shared-networks'][i].location] = 0;

				if (typeof alert_status_networks_critical[dhcp_data['shared-networks'][i].location] === "undefined")
					alert_status_networks_critical[dhcp_data['shared-networks'][i].location] = 0;

				/*
				 console.log("Location: %s", dhcp_data['shared-networks'][i].location);
				 console.log("Used: %s", dhcp_data['shared-networks'][i].used.toLocaleString('en'));
				 console.log("Defined: %s", dhcp_data['shared-networks'][i].defined.toLocaleString('en'));
				 console.log("Free: %s", dhcp_data['shared-networks'][i].free.toLocaleString('en'));
				 console.log("Utilization: %s", utilization);
				 console.log(" \n");
				 */

				/* Check Warnings */
				if (glass_config.shared_network_warning_threshold > 0) {
					if (
						utilization >= glass_config.shared_network_warning_threshold &&
						utilization <= glass_config.shared_network_critical_threshold &&
						alert_status_networks_warning[dhcp_data['shared-networks'][i].location] === 0
					) {
						alert_status_networks_warning[dhcp_data['shared-networks'][i].location] = 1;

						slack_message(":warning: WARNING: DHCP shared network utilization (" + dhcp_data['shared-networks'][i].location + ") " +
										  "Current: (" + utilization + "%) " +
										  "Threshold: (" + glass_config.shared_network_warning_threshold + "%)"
						);

						email_alert("WARNING: DHCP shared network utilization",
									"WARNING: DHCP shared network utilization (" + dhcp_data['shared-networks'][i].location + ") <br><br>" +
										"Threshold: (" + glass_config.shared_network_warning_threshold + "%) <br>" +
										"Current: (" + utilization + "%)"
						);

					}
					else if (
						utilization <= glass_config.shared_network_warning_threshold &&
						alert_status_networks_warning[dhcp_data['shared-networks'][i].location] === 1
					) {
						alert_status_networks_warning[dhcp_data['shared-networks'][i].location] = 0;

						slack_message(":white_check_mark: CLEAR: Warning DHCP shared network utilization (" + dhcp_data['shared-networks'][i].location + ") " +
										  "Current: (" + utilization + "%) " +
										  "Threshold: (" + glass_config.shared_network_warning_threshold + "%)"
						);

						email_alert("CLEAR: DHCP shared network utilization warning",
									"CLEAR: DHCP shared network utilization (" + dhcp_data['shared-networks'][i].location + ") <br><br>" +
										"Threshold: (" + glass_config.shared_network_warning_threshold + "%) <br>" +
										"Current: (" + utilization + "%)"
						);

					}
				}

				/* Check Critical */
				if (glass_config.shared_network_critical_threshold > 0) {
					if (
						utilization >= glass_config.shared_network_critical_threshold &&
						alert_status_networks_critical[dhcp_data['shared-networks'][i].location] === 0
					) {
						alert_status_networks_critical[dhcp_data['shared-networks'][i].location] = 1;
						slack_message(":fire: CRITICAL: DHCP shared network utilization (" + dhcp_data['shared-networks'][i].location + ") " +
										  "Current: (" + utilization + "%) " +
										  "Threshold: (" + glass_config.shared_network_critical_threshold + "%)"
						);

						email_alert("CRITICAL: DHCP shared network utilization",
									"CRITICAL: DHCP shared network utilization (" + dhcp_data['shared-networks'][i].location + ") <br><br>" +
										"Threshold: (" + glass_config.shared_network_critical_threshold + "%) <br>" +
										"Current: (" + utilization + "%)"
						);

					}
					else if (
						utilization <= glass_config.shared_network_critical_threshold &&
						alert_status_networks_critical[dhcp_data['shared-networks'][i].location] === 1
					) {
						alert_status_networks_critical[dhcp_data['shared-networks'][i].location] = 0;
						slack_message(":white_check_mark: CLEAR: Critical DHCP shared network utilization (" + dhcp_data['shared-networks'][i].location + ") " +
										  "Current: (" + utilization + "%) " +
										  "Threshold: (" + glass_config.shared_network_critical_threshold + "%)"
						);

						email_alert("CLEAR: DHCP shared network utilization",
									"CLEAR: DHCP shared network utilization (" + dhcp_data['shared-networks'][i].location + ") <br><br>" +
										"Threshold: (" + glass_config.shared_network_critical_threshold + "%) <br>" +
										"Current: (" + utilization + "%)"
						);
					}
				}
			}
		}
	}, (5 * 1000));
}, 60 * 1000);

function round(num, places) {
	var multiplier = Math.pow(10, places);
	return Math.round(num * multiplier) / multiplier;
}

/* Load Mailer */
const nodemailer = require('nodemailer');

let transporter = nodemailer.createTransport(
	{
		sendmail: true,
		newline:  'unix',
		path:     '/usr/sbin/sendmail'
	}
);

function email_alert(alert_title, alert_message) {
	if (typeof glass_config.email_alert_to === "undefined" && typeof glass_config.sms_alert_to === "undefined") {
		console.log("[Glass Server] E-Mail alert triggered, but no addresses configured...");
		return false;
	}

	console.log("[Glass Server] Loading E-Mail template...");
	var fs         = require('fs');
	var email_body = fs.readFileSync('./public/templates/email_template.html', "utf8");
	console.log("[Glass Server] Loading E-Mail template... DONE...");

	/* E-Mail Template Load */
	console.log("[Glass Server] Sending E-Mail Alert...\n");

	if (glass_config.email_alert_to === "" && glass_config.sms_alert_to !== "") {
		console.log("[Glass Server] No email_to specified - returning...");
		return false;
	}

	/* Write on top of E-Mail Template */
	email_body = email_body.replace("[body_content_placeholder]", alert_message);
	email_body = email_body.replace("[alert_title]", alert_title);
	email_body = email_body.replace("[local_time]", new Date().toString());

	/* Clean extra commas etc. */
	glass_config.email_alert_to = glass_config.email_alert_to.replace(/^[,\s]+|[,\s]+$/g, '').replace(/,[,\s]*,/g, ',');

	/* Send regular HTML E-Mails */
	if (glass_config.email_alert_to.trim() !== "") {
		var mailOptions = {
			from:    "Glass Alerting Monitor glass@noreply.com",
			to:      glass_config.email_alert_to,
			subject: "[Glass] " + "(" + host_name + ") " + alert_title,
			html:    email_body,
		};
		transporter.sendMail(mailOptions, function (error, info) {
			if (error) {
				console.log(error);
			}
			else {
				console.log('Message sent: ' + info.response);
			}
		});
	}

	/* Send SMS */
	if (glass_config.sms_alert_to.trim() !== "") {
		var mailOptions = {
			from:    "Glass Alerting Monitor glass@noreply.com",
			to:      glass_config.sms_alert_to,
			subject: "[Glass] " + "(" + host_name + ") " + alert_title,
			html:    (alert_message.substring(0, 130) + "..."),
		};
		transporter.sendMail(mailOptions, function (error, info) {
			if (error) {
				console.log(error);
			}
			else {
				console.log('Message sent: ' + info.response);
			}
		});
	}
}

/**
 * Slack Hooks
 */

var Slack = require('slack-node');

webhookUri = glass_config.slack_webhook_url;

slack = new Slack();
slack.setWebhook(webhookUri);

function slack_message(message) {

	/**
	 * If webhook is not set in config, return
	 */
	if (glass_config.slack_webhook_url.trim() === "") {
		console.log("[Glass Server] Slack alert triggered, but no webhook configured...");
		return;
	}

	console.log("[Slack] %s", message);

	/**
	 * Send message
	 */
	slack.webhook(
		{
			channel:    glass_config.slack_alert_channel,
			username:   "Glass",
			icon_emoji: "https://imgur.com/wD3CcBi",
			text:       "(" + host_name + ") " + message
		},
		function (err, response) {
			console.log(response);
		}
	);
}

console.log("[Glass Server] Bootup complete");
console.log("[Glass Server] Authentication enabled - all routes require login");
console.log("[Glass Server] User roles: admin (full access), operator (read-only)");
